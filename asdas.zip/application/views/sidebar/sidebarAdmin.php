<body>
	<nav class="main-menu">
        <ul>
            <li>
                <div class="fa">
                    <img src="<?php echo base_url().'assets/LogoPotrait.png'?>" width="60" height="60">
                </div>
                <span class="nav-text">
                <img src="<?php echo base_url().'assets/LogoLandscape.png'?>" width="150" height="60">
                </span>
            </li>
            <li>
                <a href="<?php echo site_url('admin'); ?>">
                    <i class="fa fa-home fa-2x"></i>
                    <span class="nav-text">
                        Home
                    </span>
                </a>
            </li>
            <li>
                <a href="<?php echo site_url('admin/orderList'); ?>">
                    <i class="fa fa-list-alt fa-2x"></i>
                    <span class="nav-text">
                        Order List
                    </span>
                </a>
            </li>
        </ul>
        <ul class="logout">
            <li>
                <i class="fa fa-user fa-2x"></i>
                <span class="nav-text">
                    Welcome, Admin
                </span>
            </li>
            <li>
               <a href="<?php echo site_url('Login/logout');?>">
                    <i class="fa fa-sign-out fa-2x"></i>
                    <span class="nav-text">
                        LogOut
                    </span>
                </a>
            </li>  
        </ul>
    </nav>
</body>

<script>
	
</script>
