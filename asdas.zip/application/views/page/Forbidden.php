<!DOCTYPE html>
<html>
<head>
	<title>Rental UAS IF430 - Gaming Buddy</title>
	<?php echo $style;?>
</head>
<body class="home" style= "background-image: url('http://localhost/UASWebprogTeori/assets/Background/HomeBG.jpg'); 
  display: grid;
  place-items: center;
  height: 100vh;">
<h1 class="headTitle" style="top:0;"> Hey, got you 🤡! <a href="<?php echo site_url('home');?>">HomePage</a></h1>
    
</body>
</html>